<?php
session_start();
include 'conexion.php';

$data = json_decode(file_get_contents('php://input'), true);
$actividad_id = $data['actividad_id'];
$nuevo_user_id = $data['nuevo_user_id'];

$stmt = $pdo->prepare("UPDATE actividades SET numero_empleado = :nuevo_user_id WHERE id = :actividad_id");
$stmt->bindParam(':nuevo_user_id', $nuevo_user_id);
$stmt->bindParam(':actividad_id', $actividad_id);

$response = [];
if ($stmt->execute()) {
    $response['success'] = true;
} else {
    $response['success'] = false;
}

echo json_encode($response);
?>
